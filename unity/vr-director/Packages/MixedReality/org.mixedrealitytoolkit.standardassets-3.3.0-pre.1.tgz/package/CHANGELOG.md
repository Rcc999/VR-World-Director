# Changelog

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

## [3.3.0-pre.1] - 2026-05-20

### Changed

* Updated icon names in MRTK_FluentIconSet.asset and Selawik-Semibold-MRTKIcons.asset to be more descriptive. [PR #1077](https://github.com/MixedRealityToolkit/MixedRealityToolkit-Unity/pull/1077) & [PR #1119](https://github.com/MixedRealityToolkit/MixedRealityToolkit-Unity/pull/1119)

## [3.2.1] - 2025-11-12

### Fixed

* Updated dependencies to match Unity Asset Store packages. [PR #1054](https://github.com/MixedRealityToolkit/MixedRealityToolkit-Unity/pull/1054)
  * com.microsoft.mrtk.graphicstools.unity 0.8.0

## [3.2.0] - 2024-03-22

### Added

* Added unified font atlas and updated corresponding fonts and their materials. [PR #700](https://github.com/MixedRealityToolkit/MixedRealityToolkit-Unity/pull/700)

## [3.1.0] - 2024-02-09

### Added

* Added SimpleEmptyButton (Experimental) and SimpleActionButton (Experimental) prefabs plus corresponding (Experimental) assets and demoscene. [PR #635](https://github.com/MixedRealityToolkit/MixedRealityToolkit-Unity/pull/635)

### Fixed
  
* Fixed support for UPM package publishing in the Unity Asset Store. [PR #519](https://github.com/MixedRealityToolkit/MixedRealityToolkit-Unity/pull/519)
* Fixing shaders of a couple of TMPro fonts [PR #696](https://github.com/MixedRealityToolkit/MixedRealityToolkit-Unity/pull/696)
* Set the Data packages's CooperHewitt-BoldItalic SDK shader to the Graphic Tools TMPro shader [PR #696](https://github.com/MixedRealityToolkit/MixedRealityToolkit-Unity/pull/696)
